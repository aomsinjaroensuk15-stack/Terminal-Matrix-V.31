# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess # หัวใจของการรันคำสั่ง OS

app = Flask(__name__)
CORS(app) # สำคัญ! เพื่อให้เว็บคุยกับ Python ได้

@app.route('/terminal', methods=['POST'])
def terminal():
    cmd = request.json.get('command')
    try:
        # รันคำสั่งจริงในเครื่อง แล้วเก็บ Output กลับมา
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=5)
        return jsonify({"result": output.decode('utf-8')})
    except Exception as e:
        # ถ้าพิมพ์ผิด หรือคำสั่งพัง ให้ส่ง Error กลับไป
        error_msg = getattr(e, 'output', str(e))
        if isinstance(error_msg, bytes): error_msg = error_msg.decode('utf-8')
        return jsonify({"result": f"Error: {error_msg}"}), 400

if __name__ == "__main__":
    app.run(port=5000, debug=True)
